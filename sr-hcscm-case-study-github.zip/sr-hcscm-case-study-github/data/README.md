# Data Folder

Use this folder for datasets used in the case study.

Suggested files:

```text
hospital_capacity.csv
community_assignment.csv
weekly_regional_hospitalization.csv
simulated_demand_scenarios.csv
```

Do not upload confidential hospital-level procurement, patient, or inventory data unless you have permission and the data are properly anonymized.
