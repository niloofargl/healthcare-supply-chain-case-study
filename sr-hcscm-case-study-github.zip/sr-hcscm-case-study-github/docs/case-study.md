# Case Study Documentation: Estimating PPE Gown Demand Across Vancouver Island Hospitals

## Overview

This case study estimates weekly gown consumption attributable to hospitalized patients across the Vancouver Island Health Authority (VIHA) during COVID-19. The model is intended for situations in which direct procurement or ward-level gown utilization data are unavailable, but weekly COVID-19 inpatient counts are available.

The hospital set $K$ includes NA, CR, CV, CD, VG, RJ, WCG, and SP. Bed counts for these hospitals were collected from each hospital website, giving a total acute-care capacity of **1,831 beds** across the eight sites.

## Mathematical Formulation

Let $k$ and $n$ index hospitals and epidemiological weeks, respectively. Let $d_k^n$ denote the average daily number of hospitalized COVID-19 patients during week $n$ at hospital $k$.

To convert patient counts into gown demand, we assume that each hospitalized COVID-19 patient generated an average of:

$$
\sigma = 33
$$

gowns per patient-day under routine contact/isolation practice.

Considering that one gown box contains:

$$
GB = 20
$$

gowns, weekly gown-box consumption is estimated as:

$$
G_k^n = \left(\frac{7\sigma}{GB}\right)d_k^n
$$

Thus, under the routine-use assumption adopted here, each additional hospitalized COVID-19 patient in the weekly average daily census corresponds to an estimated **11.55 gown boxes per week**.

## Data Source and Limitation

Weekly COVID-19 hospitalization data for Vancouver Island were obtained from the British Columbia Centre for Disease Control public COVID-19 dashboard using the Island Health regional series.

However, because of privacy and security concerns, hospital-level patient data were not publicly available. To address this limitation, patient demand for each hospital was estimated using:

1. Community population,
2. Hospital bed capacity,
3. Geographic service-area assignment.

## Community-to-Hospital Assignment

| Community | Total Population | Assigned Hospital(s) |
|---|---:|---|
| Greater Victoria | 344,615 | RJ, SP, VG |
| Nanaimo | 98,021 | NA |
| Parksville--Qualicum | 27,822 | NA |
| Ladysmith | 7,921 | NA |
| Comox Valley | 55,213 | CV |
| Cowichan | 43,252 | CD |
| Campbell River | 36,096 | CR |
| Port Alberni | 25,465 | WCG |

For communities with only one assigned hospital, such as NA and CR, all community demand was allocated entirely to that hospital.

For communities with multiple assigned hospitals, such as Greater Victoria, total demand was divided among hospitals proportionally based on bed capacity.

## Geographic and Capacity Data

| HF | Latitude | Longitude | Number of Beds |
|---|---:|---:|---:|
| CR | 50.0264 | -125.2463 | 96 |
| CV | 49.7016 | -124.9488 | 153 |
| CD | 48.7824 | -123.7025 | 134 |
| NA | 49.1867 | -123.9855 | 409 |
| VG | 48.4828 | -123.4599 | 344 |
| RJ | 48.4350 | -123.3340 | 500 |
| WCG | 49.2488 | -124.8105 | 52 |
| SP | 48.6499 | -123.4181 | 143 |

For Greater Victoria, the cumulative demand was distributed across RJ, SP, and VG according to each hospital's bed-capacity share:

| Hospital | Bed Count | Demand Share |
|---|---:|---:|
| RJ | 500 | 50.6% |
| SP | 143 | 14.5% |
| VG | 344 | 34.9% |

This approach assumes that hospitals with larger bed capacities can accommodate a proportionally higher number of patients.

## Stochastic Demand Simulation

After estimating weekly hospital-level demand, stochastic variability was incorporated to better reflect real-world conditions. Specifically, the estimated number of hospitalized COVID-19 patients at each hospital was treated as the mean of a Poisson random variable.

Based on this approach, **1,000 scenarios** were generated for each hospital and product type.

## Figure

The resulting simulated demand distributions can be shown using the following file path:

```markdown
![Weekly demand patterns for PPE services across eight hospitals](../Figures/demand_distribution.png)
```

![Weekly demand patterns for PPE services across eight hospitals](../Figures/demand_distribution.png)

## Suggested Use in Repository

This case-study documentation can be used as:

- A methodological description for AI-based healthcare supply chain simulations,
- A supporting document for demand-generation code,
- A reproducibility note for scenario generation,
- A transparent explanation of assumptions when hospital-level demand data are unavailable.
