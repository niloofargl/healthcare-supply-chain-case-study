# Source Code Folder

Use this folder for scripts related to:

- Demand estimation,
- Poisson scenario generation,
- Healthcare facility allocation,
- Supply chain simulation,
- AI or reinforcement-learning experiments.

Suggested files:

```text
estimate_weekly_demand.py
generate_scenarios.py
plot_demand_distribution.py
```
